# BiliStats（哔哩哔哩每日成长记录）

Android 原生项目，Kotlin + Jetpack Compose + Room。

## 当前版本

- Bilibili 网页二维码登录（不收集账号密码）；登录会话使用 Android EncryptedSharedPreferences 加密保存。
- 获取账号 UID、昵称、头像 URL、等级、当前经验、升级所需经验和硬币余额。
- 拉取近期经验流水、硬币流水，按中国标准时间归档为每日收入、支出、净变化。
- Room 本地保存流水和每日汇总；WorkManager 每 6 小时同步一次，打开应用也会同步。
- 总览、经验、硬币、流水四个页面；支持退出登录。

## 构建 APK

### Android Studio

1. 安装 Android Studio（建议 Koala 或更新版本）及 Android SDK 35。
2. 打开本目录 `BiliStats`。
3. 等待 Gradle Sync 完成。
4. 选择 `Build > Build Bundle(s) / APK(s) > Build APK(s)`。
5. Debug APK 输出在 `app/build/outputs/apk/debug/app-debug.apk`。

### 命令行

需要 JDK 17、Gradle 8.9 和 Android SDK 35：

```bash
gradle assembleDebug
```

## GitHub Actions 自动构建

在 GitHub 新建一个空仓库，将解压后的项目文件全部上传并推送到 `main` 分支；打开仓库的 Actions 页面，运行 `Build Android APK`（也会在推送 main/master 时自动运行）。构建成功后打开该次运行记录，在 Artifacts 区域下载 `BiliStats-debug-apk`，解压后即可取得 `app-debug.apk`。安装时允许 Android 安装来自该来源的应用。

## 数据与接口说明

当前版本使用 Bilibili 网页二维码登录流程及其 Web API：

- `GET /x/space/myinfo`
- `GET /x/member/web/exp/log`
- `GET /x/member/web/coin/log`

这些接口属于 Bilibili 网站接口，并非稳定的第三方公共 API；接口、风控策略或登录流程变化可能导致同步失败。经验和硬币流水接口目前只返回近期记录（公开接口资料标注约一周），因此应用只能从首次运行/首次成功同步开始长期积累，不能保证恢复此前更早的历史流水。首次同步会尽量导入接口当前可提供的近期流水。

登录采用 Bilibili 网页二维码会话方式，不是开放平台 OAuth 应用授权。若要正式公开发布，建议申请 Bilibili 开放平台应用并完成安全、隐私及接口权限审核；部分用户数据接口未必向第三方 OAuth 应用开放。

## 安全说明

- 不要求用户输入 Bilibili 密码。
- 登录 Cookie 仅存储在 Android 加密偏好设置中；清除应用数据或退出登录会清除本地会话。
- Cookie 只用于请求 Bilibili API，不应分享、截图或上传到 issue。
- 本项目未配置第三方服务器，不会把 Cookie 发送到自建后端。
- 仅供个人账号数据查看；请遵守 Bilibili 用户协议和相关法律法规。

## 当前限制 / 后续工作

- 当前没有在本执行环境中完成 Android SDK 编译；APK 需要通过 Android Studio 或 GitHub Actions 构建。
- 登录会话失效时需要重新扫码；当前没有静默续期。
- 图表目前以每日明细列表呈现，后续可增加折线图、CSV 导出、同步状态和失败重试提示。
- 用户资料接口和流水接口字段若发生变化，需要更新解析器。
