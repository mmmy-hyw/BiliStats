package com.bilistats.app.data

import android.content.Context
import androidx.room.Room
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class SyncRepository(context: Context) {
    private val db = Room.databaseBuilder(context, StatsDatabase::class.java, "bili_stats.db").build()
    private val api = BiliApi()
    suspend fun sync(cookie: String): BiliProfile {
        val profile = api.profile(cookie)
        val exp = api.experienceLog(cookie)
        val coins = api.coinLog(cookie)
        val all = exp.map { TransactionEntity("exp", it.timestamp, it.delta, it.reason) } + coins.map { TransactionEntity("coin", it.timestamp, it.delta, it.reason) }
        db.dao().putTransactions(all)
        val grouped = all.groupBy { day(it.timestamp) }
        val rows = mutableListOf<DailyStat>()
        grouped.forEach { (day, entries) ->
            listOf("exp", "coin").forEach { kind ->
                val subset = entries.filter { it.kind == kind }
                val positive = subset.filter { it.delta > 0 }.sumOf { it.delta }
                val negative = -subset.filter { it.delta < 0 }.sumOf { it.delta }
                rows += DailyStat(day, kind, positive, negative, positive - negative, System.currentTimeMillis())
            }
        }
        db.dao().putDaily(rows)
        return profile
    }
    suspend fun daily(kind: String) = db.dao().daily(kind)
    suspend fun transactions() = db.dao().transactions()
    private fun day(time: Long) = SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).apply { timeZone = TimeZone.getTimeZone("Asia/Shanghai") }.format(Date(time))
}
