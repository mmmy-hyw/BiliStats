package com.bilistats.app.data

import androidx.room.*

@Dao interface StatsDao {
    @Query("SELECT * FROM daily_stats WHERE kind = :kind ORDER BY day DESC") suspend fun daily(kind: String): List<DailyStat>
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC") suspend fun transactions(): List<TransactionEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putDaily(rows: List<DailyStat>)
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun putTransactions(rows: List<TransactionEntity>)
}

@Database(entities = [DailyStat::class, TransactionEntity::class], version = 1, exportSchema = false)
abstract class StatsDatabase : RoomDatabase() { abstract fun dao(): StatsDao }
