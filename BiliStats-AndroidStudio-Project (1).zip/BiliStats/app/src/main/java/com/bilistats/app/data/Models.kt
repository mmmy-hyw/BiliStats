package com.bilistats.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

data class BiliProfile(val uid: Long, val name: String, val face: String, val level: Int, val currentExp: Int, val nextExp: Int, val coins: Double)
data class DeltaRecord(val timestamp: Long, val delta: Double, val reason: String)
data class QrTicket(val url: String, val key: String)
data class QrPoll(val code: Int, val message: String, val url: String?)

@Entity(tableName = "daily_stats", primaryKeys = ["day", "kind"])
data class DailyStat(val day: String, val kind: String, val earned: Double, val spent: Double, val net: Double, val updatedAt: Long)

@Entity(tableName = "transactions", primaryKeys = ["kind", "timestamp", "delta", "reason"])
data class TransactionEntity(val kind: String, val timestamp: Long, val delta: Double, val reason: String)
