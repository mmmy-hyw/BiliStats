package com.bilistats.app

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.bilistats.app.data.AuthStore
import com.bilistats.app.data.SyncRepository

class SyncWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = try {
        val cookie = AuthStore(applicationContext).cookie
        if (cookie.isBlank()) Result.success() else { SyncRepository(applicationContext).sync(cookie); Result.success() }
    } catch (_: Exception) { Result.retry() }
}
