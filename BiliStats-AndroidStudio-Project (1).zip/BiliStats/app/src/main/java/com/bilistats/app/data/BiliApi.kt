package com.bilistats.app.data

import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit

class BiliApi {
    private val http = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(20, TimeUnit.SECONDS).build()
    private fun get(url: String, cookie: String = ""): JSONObject {
        val b = Request.Builder().url(url).header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            .header("Referer", "https://www.bilibili.com/")
        if (cookie.isNotBlank()) b.header("Cookie", cookie)
        http.newCall(b.build()).execute().use { response ->
            if (!response.isSuccessful) error("HTTP ${response.code}")
            return JSONObject(response.body?.string() ?: error("空响应"))
        }
    }

    fun generateQr(): QrTicket {
        val j = get("https://passport.bilibili.com/x/passport-login/web/qrcode/generate")
        if (j.optInt("code") != 0) error(j.optString("message", "二维码生成失败"))
        val d = j.getJSONObject("data")
        return QrTicket(d.getString("url"), d.getString("qrcode_key"))
    }

    fun qrBitmap(url: String, size: Int = 640): Bitmap {
        val matrix = QRCodeWriter().encode(url, BarcodeFormat.QR_CODE, size, size)
        return Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888).also { bmp ->
            for (x in 0 until size) for (y in 0 until size) bmp.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)
        }
    }

    fun pollQr(key: String): QrPoll {
        val j = get("https://passport.bilibili.com/x/passport-login/web/qrcode/poll?qrcode_key=$key")
        val d = j.optJSONObject("data") ?: JSONObject()
        return QrPoll(d.optInt("code", j.optInt("code")), d.optString("message", j.optString("message")), d.optString("url").takeIf { it.isNotBlank() && it != "null" })
    }

    fun cookieFromLoginUrl(url: String): String {
        val query = Uri.parse(url).encodedQuery ?: error("登录回调缺少参数")
        val values = query.split('&').mapNotNull {
            val p = it.split('=', limit = 2); if (p.size == 2) URLDecoder.decode(p[0], "UTF-8") to URLDecoder.decode(p[1], "UTF-8") else null
        }.toMap()
        val names = listOf("SESSDATA", "bili_jct", "DedeUserID", "DedeUserID__ckMd5", "sid")
        val parts = names.mapNotNull { n -> values[n]?.let { "$n=$it" } }
        if (parts.none { it.startsWith("SESSDATA=") }) error("未能从登录结果中读取会话信息")
        return parts.joinToString("; ")
    }

    fun profile(cookie: String): BiliProfile {
        val j = get("https://api.bilibili.com/x/space/myinfo?jsonp=jsonp", cookie)
        if (j.optInt("code") != 0) error("用户资料读取失败：${j.optString("message")}")
        val d = j.getJSONObject("data"); val exp = d.optJSONObject("level_exp") ?: JSONObject()
        return BiliProfile(d.optLong("mid"), d.optString("name"), d.optString("face"), d.optInt("level"), exp.optInt("current_exp"), exp.optInt("next_exp"), d.optDouble("coins"))
    }

    fun experienceLog(cookie: String): List<DeltaRecord> = records(get("https://api.bilibili.com/x/member/web/exp/log?jsonp=jsonp&web_location=333.33", cookie), "经验流水")
    fun coinLog(cookie: String): List<DeltaRecord> = records(get("https://api.bilibili.com/x/member/web/coin/log?jsonp=jsonp", cookie), "硬币流水")

    private fun records(j: JSONObject, label: String): List<DeltaRecord> {
        if (j.optInt("code") != 0) error("$label读取失败：${j.optString("message")}")
        val data = j.optJSONObject("data") ?: return emptyList()
        val list = data.optJSONArray("list") ?: return emptyList()
        return (0 until list.length()).mapNotNull { i ->
            val o = list.optJSONObject(i) ?: return@mapNotNull null
            val time = o.optString("time")
            val epoch = try { java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).apply { timeZone = java.util.TimeZone.getTimeZone("Asia/Shanghai") }.parse(time)?.time ?: 0L } catch (_: Exception) { 0L }
            if (epoch == 0L) null else DeltaRecord(epoch, o.optDouble("delta"), o.optString("reason"))
        }
    }
}
