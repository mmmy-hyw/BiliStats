package com.bilistats.app

import android.graphics.Bitmap
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.work.*
import com.bilistats.app.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val auth = AuthStore(this)
        val repo = SyncRepository(this)
        val work = PeriodicWorkRequestBuilder<SyncWorker>(6, TimeUnit.HOURS).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("bili_periodic_sync", ExistingPeriodicWorkPolicy.KEEP, work)
        setContent { BiliStatsApp(auth, repo) }
    }
}

@Composable private fun BiliStatsApp(auth: AuthStore, repo: SyncRepository) {
    val scope = rememberCoroutineScope()
    var cookie by remember { mutableStateOf(auth.cookie) }
    var profile by remember { mutableStateOf<BiliProfile?>(null) }
    var qr by remember { mutableStateOf<Bitmap?>(null) }
    var qrKey by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("登录后开始记录每日数据") }
    var busy by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var expRows by remember { mutableStateOf<List<DailyStat>>(emptyList()) }
    var coinRows by remember { mutableStateOf<List<DailyStat>>(emptyList()) }
    var txRows by remember { mutableStateOf<List<TransactionEntity>>(emptyList()) }
    val api = remember { BiliApi() }

    suspend fun refresh() {
        if (cookie.isBlank()) return
        busy = true
        try {
            profile = withContext(Dispatchers.IO) { repo.sync(cookie) }
            expRows = repo.daily("exp"); coinRows = repo.daily("coin"); txRows = repo.transactions()
            status = "同步成功 · ${SimpleDateFormat("HH:mm", Locale.CHINA).format(Date())}"
        } catch (e: Exception) { status = e.message ?: "同步失败" }
        busy = false
    }

    LaunchedEffect(cookie) { if (cookie.isNotBlank()) refresh() }

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF00A1D6), background = androidx.compose.ui.graphics.Color(0xFFF4F7FA))) {
        Scaffold(containerColor = MaterialTheme.colorScheme.background, topBar = {
            TopAppBarCompat(title = "BiliStats", subtitle = "B站每日成长记录")
        }, bottomBar = {
            NavigationBar {
                listOf("总览", "经验", "硬币", "明细").forEachIndexed { i, label ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(listOf("◉", "↗", "◎", "☷")[i]) }, label = { Text(label) })
                }
            }
        }) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 14.dp)) {
                if (cookie.isBlank()) {
                    item { CardBlock {
                        Text("连接 Bilibili 账号", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("使用 Bilibili 扫码登录。应用不会要求你输入账号密码。", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Button(enabled = !busy, onClick = {
                            busy = true; status = "正在生成二维码…"
                            scope.launch { try { val ticket = withContext(Dispatchers.IO) { api.generateQr() }; qrKey = ticket.key; qr = withContext(Dispatchers.IO) { api.qrBitmap(ticket.url) }; status = "请使用 Bilibili 手机客户端扫码" } catch (e: Exception) { status = e.message ?: "二维码生成失败" }; busy = false }
                        }) { Text("生成登录二维码") }
                        qr?.let { Image(it.asImageBitmap(), null, Modifier.size(230.dp).align(Alignment.CenterHorizontally) ) }
                        if (qrKey.isNotBlank() && cookie.isBlank()) {
                            LaunchedEffect(qrKey) {
                                while (cookie.isBlank()) {
                                    delay(2500)
                                    try {
                                        val result = withContext(Dispatchers.IO) { api.pollQr(qrKey) }
                                        when (result.code) {
                                            0 -> if (result.url != null) { val c = withContext(Dispatchers.IO) { api.cookieFromLoginUrl(result.url) }; auth.cookie = c; cookie = c; qr = null; status = "登录成功，正在同步" }
                                            86090 -> status = "已扫码，请在手机上确认登录"
                                            86038 -> { status = "二维码已过期，请重新生成"; qr = null; qrKey = "" }
                                            86101 -> status = "等待扫码…"
                                        }
                                    } catch (_: Exception) { status = "登录状态检查失败，请检查网络" }
                                }
                            }
                        }
                        Text(status, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } }
                } else {
                    item { CardBlock {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.weight(1f)) {
                                Text(profile?.name ?: "Bilibili 用户", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Text("UID ${profile?.uid ?: "读取中"} · Lv.${profile?.level ?: "—"}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            OutlinedButton(onClick = { scope.launch { refresh() } }, enabled = !busy) { Text(if (busy) "同步中" else "立即同步") }
                        }
                        Text(status, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } }
                    when (tab) {
                        0 -> {
                            item { MetricCard("当前经验", profile?.currentExp?.toString() ?: "—", "距离下一级 ${((profile?.nextExp ?: 0) - (profile?.currentExp ?: 0)).coerceAtLeast(0)} 经验") }
                            item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricCard("当前硬币", profile?.coins?.let { fmt(it) } ?: "—", "账户余额", Modifier.weight(1f)); MetricCard("今日经验", dailyToday(expRows)?.net?.let { signed(it) } ?: "—", "来自流水记录", Modifier.weight(1f)) } }
                            item { HistorySection("最近经验记录", expRows.take(5), "exp") }
                            item { HistorySection("最近硬币记录", coinRows.take(5), "coin") }
                        }
                        1 -> { item { MetricCard("累计记录经验净变化", signed(expRows.sumOf { it.net }), "本地已保存的流水汇总") }; item { HistorySection("每日经验变化", expRows, "exp") } }
                        2 -> { item { MetricCard("累计记录硬币净变化", signed(coinRows.sumOf { it.net }), "收入减去支出") }; item { HistorySection("每日硬币收支", coinRows, "coin") } }
                        else -> items(txRows.take(100)) { row -> CardBlock { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Column(Modifier.weight(1f)) { Text(row.reason.ifBlank { if (row.kind == "exp") "经验变动" else "硬币变动" }, fontWeight = FontWeight.Medium); Text(SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(Date(row.timestamp)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Text(signed(row.delta), color = if (row.delta >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold) } } }
                    }
                    item { OutlinedButton(onClick = { auth.clear(); cookie = ""; profile = null; expRows = emptyList(); coinRows = emptyList(); txRows = emptyList(); status = "已退出登录" }, modifier = Modifier.fillMaxWidth()) { Text("退出账号") } }
                }
                item { Text("数据按中国标准时间（UTC+8）归档。接口仅提供有限历史记录，首次同步前的流水可能无法恢复。", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
        }
    }
}

@Composable private fun TopAppBarCompat(title: String, subtitle: String) {
    Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 1.dp) { Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp)) { Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Text(subtitle, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
}
@Composable private fun CardBlock(content: @Composable ColumnScope.() -> Unit) { Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content) } }
@Composable private fun MetricCard(title: String, value: String, hint: String, modifier: Modifier = Modifier) { Card(modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { Text(title, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelLarge); Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text(hint, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } } }
@Composable private fun HistorySection(title: String, rows: List<DailyStat>, kind: String) { CardBlock { Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); if (rows.isEmpty()) Text("暂无记录。完成登录并同步后开始积累数据。", color = MaterialTheme.colorScheme.onSurfaceVariant) else rows.forEach { r -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(r.day); Column(horizontalAlignment = Alignment.End) { Text(signed(r.net), fontWeight = FontWeight.Bold, color = if (r.net >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error); if (kind == "coin") Text("收入 ${fmt(r.earned)} · 支出 ${fmt(r.spent)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } } } } }
private fun dailyToday(rows: List<DailyStat>): DailyStat? { val today = SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).format(Date()); return rows.firstOrNull { it.day == today } }
private fun fmt(v: Double) = if (v % 1.0 == 0.0) v.toInt().toString() else String.format(Locale.US, "%.2f", v)
private fun signed(v: Double) = (if (v > 0) "+" else "") + fmt(v)
